MYTHIC FORGE 0.1.0 - Windows 64-bit portable edition
Produced by Mythic Bharat Studios. Create. Build. Play.

HOW TO RUN
1. Extract the whole folder anywhere on your PC.
2. Double-click MythicForge.exe.

Mythic Forge opens in a Microsoft Edge app window (Edge is part of Windows 10 and 11).
Everything runs on this PC: the launcher serves the app on 127.0.0.1 port 47831 and
needs no internet connection. Projects are saved in the app window's own storage under
%LOCALAPPDATA%\MythicBharatStudios\MythicForge. Export important projects
(Project > Export .mfpack) to keep a copy you can move to other devices.

Documentation: https://github.com/piyushmali61/mythic-forge

(c) 2026 Mythic Bharat Studios. All rights reserved. See LICENSE.txt.
Open-source components: app/THIRD_PARTY_NOTICES.md
