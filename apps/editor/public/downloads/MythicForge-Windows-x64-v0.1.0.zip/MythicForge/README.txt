========================================================
MYTHIC FORGE v0.1.0 (Windows 64-bit Desktop Edition)
Produced by Mythic Bharat Studios
Create. Build. Play.
========================================================

HOW TO RUN:
1. Extract this folder anywhere on your PC.
2. Double-click "MythicForge.exe" to start creating!

FEATURES:
- 100% Offline-First (No internet required)
- Zero Installation Required (Fully portable)
- Low Battery Consumption (0 FPS render-on-demand when idle)
- Cross-platform .mfpack project compatibility

Documentation & Updates:
https://github.com/piyushmali61/mythic-forge

© 2026 Mythic Bharat Studios. All Rights Reserved.
========================================================
